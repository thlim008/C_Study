#define START_ID 0
#define START_BookID 1

typedef struct tagBook
{
    int book_num;
    char book_name[150];
    char book_author[150];
    char book_birth[150];
    char book_review[150];
    int book_price;
    char member_id[150];
}BOOK;

typedef struct member 
{
    int member_num;
    char member_id[150];
    char member_password[150];
    char member_name[150];
    char member_phonenum[150];
    char member_email[150];
    int member_birth;
    char member_admin[1];
}Member;