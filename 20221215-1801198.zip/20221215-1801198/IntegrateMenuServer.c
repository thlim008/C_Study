#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<dirent.h>
#include<time.h>
#include"IntegrateMenu.h"
#include <sys/socket.h>
#include <netinet/in.h>

void c_print(int sock, char* msg);
char *c_read(int sock, char* msg);
void error(char *msg);

int Memberwrite_file()
{
    int fd = open("Member.dbx", O_RDWR | O_CREAT, 0644);
    return fd;
}
int Memberrdwr_file()
{
    int fd = open("Member.dbx", O_RDWR, 0644);
    return fd;
}
int Bookwrite_file()
{
    int fd = open("Book.dbx", O_RDWR | O_CREAT, 0644);
    return fd;
}
int Bookrdwr_file()
{
    int fd = open("Book.dbx", O_RDWR, 0644);
    return fd;
}
int Admin_member_rdwr_file()
{
    int fd = open("Member.dbx", O_RDWR);
    return fd;
}
int fd_rdlock(int id, int fd)
{
    struct flock lock;
    BOOK book;
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = id*sizeof(book);
    lock.l_len = sizeof(book);

    return fcntl(fd, F_SETLKW, &lock);
}
int fd_unlock(int id, int fd)
{
    struct flock lock;
    BOOK book;
    lock.l_type = F_UNLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = id*sizeof(book);
    lock.l_len = sizeof(book);

    return fcntl(fd, F_SETLK, &lock);
}
int fd_wrlock(int id, int fd)
{
    struct flock lock;
    BOOK book;
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = id*sizeof(book);
    lock.l_len = sizeof(book);

    return fcntl(fd, F_SETLK, &lock);
}

void Adminbook_sortnumprint(int fd, int sock)
{
    BOOK book_data;
    BOOK temp;
    BOOK name_sort[150] = {0, };
    char buffer[250];
    int i = 0;
    int n = sizeof(name_sort)/sizeof(book_data);
    while(1)
    {
        fd_rdlock(i, fd);   
        int ret = read(fd, (char*)&book_data, sizeof(book_data));
        if(ret != sizeof(book_data)) break;
        name_sort[i] = book_data;

        i++;
    }
    for(int i = 0; i < n - 1; i++)
    {
        for(int j = i + 1; j < n; j++)
        {
            if(strcmp(name_sort[i].book_name, name_sort[j].book_name) > 0)
            {
                temp = name_sort[i];
                name_sort[i] = name_sort[j];
                name_sort[j] = temp;
            }
        }
    }
    c_print(sock, "ID | 도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰\n");
    for(int j = 0; j < n; j++) 
    {
        if(name_sort[j].book_num != 0)
        {
            c_print(sock,name_sort[j].member_id);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d", name_sort[j].book_num);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, name_sort[j].book_name);c_print(sock, " "); 
            c_print(sock, name_sort[j].book_name);c_print(sock, " ");
            c_print(sock, name_sort[j].book_author);c_print(sock, " "); 
            c_print(sock, name_sort[j].book_birth);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d",  name_sort[j].book_price);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, name_sort[j].book_review);c_print(sock, " ");
        }
        fd_unlock(j, fd);              
    }
    c_print(sock, "\n");
    close(fd);
    
}

void Adminbook_sortnameprint(int fd, int sock)
{
    BOOK book_data;
    BOOK temp;
    BOOK name_sort[150] = {0, };
    char buffer[250];
    int i = 0;
    int n = sizeof(name_sort)/sizeof(book_data);
    while(1)
    {
        fd_rdlock(i, fd);   
        int ret = read(fd, (char*)&book_data, sizeof(book_data));
        if(ret != sizeof(book_data)) break;
        name_sort[i] = book_data;

        i++;
    }
    for(int i = 0; i < n - 1; i++)
    {
        for(int j = i + 1; j < n; j++)
        {
            if(strcmp(name_sort[i].member_id, name_sort[j].member_id) > 0)
            {
                temp = name_sort[i];
                name_sort[i] = name_sort[j];
                name_sort[j] = temp;
            }
        }
    }
    c_print(sock, "ID | 도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰\n");
    for(int i = 0; i < n; i++) 
    {
        if(name_sort[i].book_num != 0)
        {
            c_print(sock,name_sort[i].member_id);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d", name_sort[i].book_num);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, name_sort[i].book_name);c_print(sock, " "); 
            c_print(sock, name_sort[i].book_name);c_print(sock, " ");
            c_print(sock, name_sort[i].book_author);c_print(sock, " "); 
            c_print(sock, name_sort[i].book_birth);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d",  name_sort[i].book_price);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, name_sort[i].book_review);c_print(sock, " ");
        }
        fd_unlock(i, fd);              
    }
    c_print(sock, "\n");
    close(fd);
}
void Adminbook_addMenu(int fd, int sock)
{
    char answer[1];
    char buffer[150];
    BOOK book;
    int i =0;
    do
    {
            fd_wrlock(i, fd);
	        c_print(sock, "도서 정보를 입력하세요\n");
            bzero(book.member_id, 150);
            strcpy(book.member_id, c_read(sock, "ID: "));
            bzero(buffer, 150);
            strcpy(buffer, c_read(sock, "도서 식별 번호: "));
            book.book_num = atoi(buffer);
            bzero(book.book_name, 150);
            strcpy(book.book_name, c_read(sock, "도서 이름: "));
            bzero(book.book_author, 150);
            strcpy(book.book_author, c_read(sock, "저자 : "));
            bzero(book.book_birth, 150);
            strcpy(book.book_birth, c_read(sock, "출판년월일 : "));
            bzero(buffer, 150);
            strcpy(buffer, c_read(sock, "가격(YYMMDD): "));
            book.book_price = atoi(buffer);
            bzero(book.book_review, 150);
            strcpy(book.book_review, c_read(sock, "리뷰: "));
            lseek(fd, book.book_num * sizeof(book), SEEK_SET);  
            write(fd, &book, sizeof(BOOK));
            bzero(answer, 1);
            strcpy(answer, c_read(sock, "계속 하시겠습니까? (y/n): "));
            fd_unlock(i, fd);
            i++;
    }while(!strcmp(answer,"y"));
    close(fd);
}
void Adminbook_updateMenu(int fd, int sock)
{
    int re;
    int compare;
    int i =0;
    BOOK book;
    char buffer[150];
    while(1)
    {
        bzero(buffer, 150);
        strcpy(buffer, c_read(sock, "수정할 도서의 식별 번호를 입력하세요: "));
        compare= atoi(buffer);
            lseek(fd, (long)(compare - START_ID)*sizeof(book), SEEK_SET);
            if(read(fd, (char *)&book, sizeof(book))>0 && (book.book_num!=0))
            {
                c_print(sock, "도서 정보를 입력하세요\n");
                bzero(book.book_name, 150);
                strcpy(book.book_name, c_read(sock, "도서 이름: "));
                bzero(book.book_author, 150);
                strcpy(book.book_author, c_read(sock, "저자 : "));
                bzero(book.book_birth, 150);
                strcpy(book.book_birth, c_read(sock, "출판년월일 : "));
                bzero(buffer, 150);
                strcpy(buffer, c_read(sock, "가격(YYMMDD): "));
                book.book_price = atoi(buffer);
                bzero(book.book_review, 150);
                strcpy(book.book_review, c_read(sock, "리뷰: "));
                lseek(fd, (long) -sizeof(book), SEEK_CUR);
                write(fd, (char*) &book, sizeof(book));
                break;
            }
        fd_unlock(i, fd);
        i++;
    }
    close(fd);  
}
void Adminbook_delteMenu(int fd, int sock)
{
    int re;
    int compare;
    int i = 0;
    BOOK book;
    char buffer[150];
    while(1)
    {
        fd_wrlock(i, fd);
        bzero(buffer, 150);
        strcpy(buffer, c_read(sock, "삭제할 도서의 식별 번호를 입력하세요: "));
        compare= atoi(buffer);
            lseek(fd, (long)(compare - START_ID)*sizeof(book), SEEK_SET);
            if(read(fd, (char *) &book, sizeof(book))>0 && (book.book_num!=0))
            {
                book.book_num = 0;
                lseek(fd, (long) -sizeof(book), SEEK_CUR);
                write(fd, (char*) &book, sizeof(book));

                break;
            }
        
        fd_unlock(i, fd);
        i++;
    }
    close(fd);
}
void Adminbook_search(int fd, int sock)
{
    int re;
    int i = 1;
    char search[100];
    BOOK book;
    char buffer[250];
    bzero(search, 100);
    strcpy(search, c_read(sock, "검색할 도서의 이름을 입력하세요: "));
    while(1)
    {
        fd_rdlock(i, fd);
        re = read(fd, (char*) &book, sizeof(BOOK));
        if(re != sizeof(book)) 
        break;
        if(strstr(book.book_name, search) != NULL && book.book_num != 0)
        {
            c_print(sock, "ID | 도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
            c_print(sock,book.member_id);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d", book.book_num);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, book.book_name);c_print(sock, " "); 
            c_print(sock, book.book_name);c_print(sock, " ");
            c_print(sock, book.book_author);c_print(sock, " "); 
            c_print(sock, book.book_birth);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d",  book.book_price);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, book.book_review);c_print(sock, " ");
        }
        lseek(fd, i * sizeof(book), SEEK_SET); 
        fd_unlock(i, fd);  
        i++;
    }
    close(fd);
}
void Adminbook_searchId(int fd, int sock)
{
    int re;
    int i = 1;
    int search;
    BOOK book;
    char buffer[250];
    bzero(buffer, 250);
    strcpy(buffer, c_read(sock, "검색할 도서의 식별번호를 입력하세요: "));
    search = atoi(buffer);
    while(1)
    {
        fd_rdlock(i, fd);
        re = read(fd, (char*) &book, sizeof(BOOK));
        if(re != sizeof(book)) 
        break;
        if((search == book.book_num) && book.book_num != 0)
        {
            c_print(sock, "ID | 도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
            c_print(sock,book.member_id);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d", book.book_num);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, book.book_name);c_print(sock, " "); 
            c_print(sock, book.book_name);c_print(sock, " ");
            c_print(sock, book.book_author);c_print(sock, " "); 
            c_print(sock, book.book_birth);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d",  book.book_price);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, book.book_review);c_print(sock, " ");
        }
        lseek(fd, i * sizeof(book), SEEK_SET);   
        fd_unlock(i, fd);
        i++;
    }
    close(fd);
}
void Admin_Memberprint(int fd, int sock)
{
    int re;
    Member member;
    int i = 0;
    char buffer[250];
    while(1)
    {
        fd_rdlock(i, fd);
        re = read(fd, &member, sizeof(member));
        if(re != sizeof(member)) break;
        if(member.member_num!=0)
        {
            bzero(buffer, 250);
            sprintf(buffer, "%d", member.member_num);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, member.member_id);c_print(sock, " "); 
            c_print(sock, member.member_password);c_print(sock, " "); 
            c_print(sock, member.member_name);c_print(sock, " ");
            c_print(sock, member.member_email);c_print(sock, " "); 
            bzero(buffer, 250);
            sprintf(buffer, "%d", member.member_birth);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, member.member_admin);c_print(sock, " ");
        }
        lseek(fd, i*sizeof(member), SEEK_SET); 
        fd_unlock(i,fd); 
        i++; 
    }
    close(fd);
}
void Admin_MemberAdd(int fd, int sock)
{
    Member member, temp;
    char id[150], buffer[150];
    int a = 0;
    int i=0;
    c_print(sock, "<신규회원 삽입 >\n");
    bzero(member.member_id, 150);
    strcpy(member.member_id, c_read(sock, "id :"));
    int count3 = 1;
    while(1)
    {
        int ret = read(fd, (char*)&temp, sizeof(temp));
        if (ret != sizeof(temp)) 
        {
            break;
        }
        if(!strcmp(temp.member_id, member.member_id)){
            strcpy(id, temp.member_id);
            break;
        }
        lseek(fd, i * sizeof(temp), SEEK_SET);
        count3 = i;
        i++;
    }
    member.member_num = count3;
    if(!strcmp(id, member.member_id)){
        c_print(sock, "중복된 계정이 있습니다.\n");
        return;
    }
    if(member.member_num!=0)
    {
        if(strcmp(id, member.member_id)!= 0)
        {
            bzero(member.member_password, 150);
            strcpy(member.member_password, c_read(sock, "password: "));
            bzero(member.member_name, 150);
            strcpy(member.member_name, c_read(sock, "name: "));
            bzero(member.member_phonenum, 150);
            strcpy(member.member_phonenum, c_read(sock, "phonenum: "));
            bzero(member.member_email, 150);
            strcpy(member.member_email, c_read(sock, "email: "));
            bzero(buffer, 150);
            strcpy(buffer, c_read(sock, "생년월일(YYMMDD): "));
            member.member_birth = atoi(buffer);
            bzero(member.member_admin, 1);
            strcpy(member.member_admin, c_read(sock, "Admin 여부(Y/N): "));
            c_print(sock, "회원 가입 성공!\n");
            lseek(fd, (member.member_num - START_ID) * sizeof(member), SEEK_SET);
            write(fd, (char *)&member, sizeof(member));
        }
    }
    close(fd);
}
void Admin_MemberRemove(int fd, int book, int sock)
{
    int re;
    int compare;
    int i = 0;
    char reset ='0';
    Member member;
    BOOK adbook;
    int str_id = 1;
    char buffer[250];
    while(1)
    {
        fd_wrlock(i, fd);
        bzero(buffer, 250);
        strcpy(buffer, c_read(sock, "삭제할 회원의 식별 번호를 입력하세요"));
        compare = atoi(buffer);
            lseek(fd, (long)(compare-START_ID)*sizeof(member), SEEK_SET);
            if (read(fd, (char *)&member, sizeof(member)) > 0 && (member.member_num != 0))
            {
                for (int j = 1;; j++)
                {
                    int ret = read(book, (char *)&adbook, sizeof(adbook));
                    if (ret != sizeof(adbook))
                    {
                        break;
                    }
                        
                    if (!strcmp(member.member_id, adbook.member_id))
                    {
                        str_id = 0;
                        break;
                    }
                    lseek(book, j * sizeof(adbook), SEEK_SET);
                }

                if (str_id == 1)
                {
                    member.member_num = 0;
                    strcpy(member.member_id, "0");
                    strcpy(member.member_admin, "0");
                    member.member_birth = 0;
                    strcpy(member.member_password, "0");
                    strcpy(member.member_phonenum, "0");
                    member.member_num = 0;
                    strcpy(member.member_name, "0");
                    strcpy(member.member_email, "0");
                    lseek(fd, (long)-sizeof(member), SEEK_CUR);
                    write(fd, (char *)&member, sizeof(member));
                    break;
                }
                else
                {
                    c_print(sock,"삭제할 ID의 도서 정보가 남아있습니다.\n");
                    break;
                }
            }
            else {
                c_print(sock, "해당하는 맴버의 식별번호가 없습니다. \n");
            }
        fd_unlock(i, fd);
        i++;
    }
    close(fd);
}
void Admin_Memberupdate(int fd, int sock)
{
    int re;
    int compare;
    int i =0;
    Member member;
    char buffer[250];
    while(1)
    {
        bzero(buffer, 250);
        strcpy(buffer, c_read(sock, "삭제할 회원의 식별 번호를 입력하세요"));
        compare = atoi(buffer);
        fd_wrlock(i, fd);
        lseek(fd, (long)(compare - START_ID) * sizeof(member), SEEK_SET);
        if (read(fd, (char *)&member, sizeof(member)) > 0 && (member.member_num != 0))
        {
                bzero(member.member_id, 150);
                strcpy(member.member_id, c_read(sock, "ID: "));
                bzero(member.member_password, 150);
                strcpy(member.member_password, c_read(sock, "password: "));
                bzero(member.member_name, 150);
                strcpy(member.member_name, c_read(sock, "name: "));
                bzero(member.member_phonenum, 150);
                strcpy(member.member_phonenum, c_read(sock, "phonenum: "));
                bzero(member.member_email, 150);
                strcpy(member.member_email, c_read(sock, "email: "));
                bzero(buffer, 150);
                strcpy(buffer, c_read(sock, "생년월일(YYMMDD): "));
                member.member_birth = atoi(buffer);
                lseek(fd, (long)-sizeof(member), SEEK_CUR);
                write(fd, (char *)&member, sizeof(member));
                break;
        }

        fd_unlock(i, fd);
        i++;
    }
    close(fd);  
}

void Admin_update(int fd, char* id, int sock)
{
    int re;
    int i = 1;
    char search[100];
    char buffer[150];
    Member member;
    c_print(sock, "개인정보 변경\n");
    while(1)
    {
        lseek(fd, (long)i * sizeof(member), SEEK_SET); 
        re = read(fd, (char*) &member, sizeof(member));
        if(!strcmp(id, member.member_id)){
            fd_rdlock(i, fd);
                bzero(member.member_id, 150);
                strcpy(member.member_id, c_read(sock, "ID: "));
                bzero(member.member_password, 150);
                strcpy(member.member_password, c_read(sock, "password: "));
                bzero(member.member_name, 150);
                strcpy(member.member_name, c_read(sock, "name: "));
                bzero(member.member_phonenum, 150);
                strcpy(member.member_phonenum, c_read(sock, "phonenum: "));
                bzero(member.member_email, 150);
                strcpy(member.member_email, c_read(sock, "email: "));
                bzero(buffer, 150);
                strcpy(buffer, c_read(sock, "생년월일(YYMMDD): "));
                member.member_birth = atoi(buffer);
            lseek(fd, (long) -sizeof(member), SEEK_CUR); 
            write(fd, (char*) &member, sizeof(member));
            break;
        }
        fd_unlock(i, fd);  
        i++;
    }
    close(fd);
}
void Admin_book_print(int sock)
{
	c_print(sock,"1) List up All Book(Sort by 식별자)\n");
	c_print(sock,"2) List up All Book(Sort by 도서명)\n");
	c_print(sock,"3) Add New Book\n");
	c_print(sock,"4) Update Book\n");
	c_print(sock,"5) Remove Book\n");
	c_print(sock,"6) Search Book Information by Title(minimum 2char)\n");
    c_print(sock,"7) 회원리스트 보기\n");
    c_print(sock,"8) 신규 회원 삽입\n");
    c_print(sock,"9) 회원 정보 삭제\n");
    c_print(sock,"10) 회원 정보 갱신\n");
    c_print(sock,"11) 개인 정보 변경\n");
    c_print(sock,"0) Quit\n");
}

void Admin_mainMenu(char * id, char* file, int sock)
{
	int start = -1;
    int read;
    int write;
    int member;
    char buffer[250];
	while (start != 0)
	{
        read = Bookrdwr_file();
        write = Bookwrite_file();
        member = Admin_member_rdwr_file();
		Admin_book_print(sock);
		bzero(buffer, 250);
        strcpy(buffer, c_read(sock, "input: "));
      start = atoi(buffer);
		if (start == 1)
		{
			Adminbook_sortnumprint(read, sock);
		}
		else if (start == 2)
		{
            Adminbook_sortnameprint(read, sock);
		}
		else if (start == 3)
		{
            Adminbook_addMenu(write, sock);   
		}
		else if (start == 4)
		{
            Adminbook_updateMenu(read, sock);
		}
		else if (start == 5)
		{
            Adminbook_delteMenu(read, sock);
		}
		else if (start == 6)
		{
           Adminbook_search(read, sock);
		}
        else if(start == 7)
        {
            Admin_Memberprint(member, sock);
        }
        else if(start == 8)
        {
            Admin_MemberAdd(member, sock);
        }
        else if(start == 9)
        {
            Admin_MemberRemove(member, read, sock);
        }
        else if(start == 10)
        {
            Admin_Memberupdate(member, sock);
        }
        else if(start == 11)
        {
            Admin_update(member, id,sock);
        }
	}
}
/*여기까지 Admin 지금부터 General*/
void book_sortnameprint(char *id, int fd, int sock)
{
    BOOK book_data;
    BOOK temp;
    BOOK name_sort[150] = {0, };
    char buffer[250];
    int i = 0;
    int n = sizeof(name_sort)/sizeof(book_data);
    while(1)
    {
        fd_rdlock(i, fd);   
        int ret = read(fd, (char*)&book_data, sizeof(book_data));
        if(ret != sizeof(book_data)) break;
        name_sort[i] = book_data;
        i++;
    }
    for(int i = 0; i < n - 1; i++)
    {
        for(int j = i + 1; j < n; j++)
        {
            if(strcmp(name_sort[i].book_name, name_sort[j].book_name) > 0)
            {
                temp = name_sort[i];
                name_sort[i] = name_sort[j];
                name_sort[j] = temp;
            }
        }
    }
    c_print(sock, "ID | 도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰\n");
    for(int j = 0; j < n; j++) 
    {
        if(name_sort[j].book_num != 0&& !strcmp(name_sort[j].member_id, id))
        {
            bzero(buffer, 250);
            sprintf(buffer, "%d", name_sort[j].book_num);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, name_sort[j].book_name);c_print(sock, " "); 
            c_print(sock, name_sort[j].book_name);c_print(sock, " ");
            c_print(sock, name_sort[j].book_author);c_print(sock, " "); 
            c_print(sock, name_sort[j].book_birth);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d",  name_sort[j].book_price);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, name_sort[j].book_review);c_print(sock, " ");
        }
        fd_unlock(j, fd);              
    }
    c_print(sock, "\n");
    close(fd);
}
void book_sortpriceprint(char *id, int fd, int sock)
{
    BOOK book, temp;
    BOOK price_sort[150] = {0,};
    char buffer[250];
    int i = 0;
    int n = sizeof(price_sort)/sizeof(book);
    while(1)
    {
        fd_rdlock(i, fd);
        int ret = read(fd, (char*) &book, sizeof(book));
        if(ret != sizeof(book))break;
        price_sort[i] = book;
        i++;
    }
    for(int i = 0; i < n -1; i++)
    {
        for(int j = i +1; j<n; j++)
        {
            if(price_sort[i].book_price > price_sort[j].book_price)
            {
                    temp = price_sort[i];
                    price_sort[i] = price_sort[j];
                    price_sort[j] =temp;
            }
        }
    }
    int k = 0;
    c_print(sock, "ID | 도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰\n");
    while(k != n)
    {
        if(price_sort[k].book_num!=0 && !strcmp(price_sort[k].member_id,id))
        {
            c_print(sock,price_sort[i].member_id);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d", price_sort[i].book_num);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, price_sort[i].book_name);c_print(sock, " "); 
            c_print(sock, price_sort[i].book_name);c_print(sock, " ");
            c_print(sock, price_sort[i].book_author);c_print(sock, " "); 
            c_print(sock, price_sort[i].book_birth);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d",  price_sort[i].book_price);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, price_sort[i].book_review);c_print(sock, " ");
        }
        fd_unlock(k,fd); 
        k++; 
    }
    c_print(sock, "\n");
    close(fd);
}
void book_addMenu(char * id, int fd, int sock)
{
    char answer[1];
    BOOK book;
    char buffer[150];
    int i =0;
    do
    {
            fd_wrlock(i, fd);
	        c_print(sock, "도서 정보를 입력하세요\n");
            bzero(buffer, 150);
            strcpy(buffer, c_read(sock, "도서 식별 번호: "));
            book.book_num = atoi(buffer);
            bzero(book.book_name, 150);
            strcpy(book.book_name, c_read(sock, "도서 이름: "));
            bzero(book.book_author, 150);
            strcpy(book.book_author, c_read(sock, "저자 : "));
            bzero(book.book_birth, 150);
            strcpy(book.book_birth, c_read(sock, "출판년월일 : "));
            bzero(buffer, 150);
            strcpy(buffer, c_read(sock, "가격(YYMMDD): "));
            book.book_price = atoi(buffer);
            bzero(book.book_review, 150);
            strcpy(book.book_review, c_read(sock, "리뷰: "));
            lseek(fd, book.book_num * sizeof(book), SEEK_SET);  
            write(fd, &book, sizeof(BOOK));
            bzero(answer, 1);
            strcpy(answer, c_read(sock, "계속 하시겠습니까? (y/n): "));
            fd_unlock(i, fd);
            i++;
    }while(!strcmp(answer,"y"));
    close(fd);
}

void book_updateMenu(char *id, int fd, int sock)
{
    int re;
    int compare;
    int i =0;
    BOOK book;
    char buffer[150];
    while(1)
    {
            bzero(buffer, 150);
            strcpy(buffer, c_read(sock, "수정할 도서의 식별 번호를 입력하세요: "));
            compare = atoi(buffer);
            lseek(fd, (long)(compare - START_ID) * sizeof(book), SEEK_SET);
            if (read(fd, (char *)&book, sizeof(book)) > 0 && (book.book_num != 0))
            {
                c_print(sock, "도서 정보를 입력하세요\n");
                bzero(book.book_name, 150);
                strcpy(book.book_name, c_read(sock, "도서 이름: "));
                bzero(book.book_author, 150);
                strcpy(book.book_author, c_read(sock, "저자 : "));
                bzero(book.book_birth, 150);
                strcpy(book.book_birth, c_read(sock, "출판년월일 : "));
                bzero(buffer, 150);
                strcpy(buffer, c_read(sock, "가격(YYMMDD): "));
                book.book_price = atoi(buffer);
                bzero(book.book_review, 150);
                strcpy(book.book_review, c_read(sock, "리뷰: "));
                lseek(fd, (long)-sizeof(book), SEEK_CUR);
                write(fd, (char *)&book, sizeof(book));
            break;
            }
        fd_unlock(i, fd);
        i++;
    }
    close(fd);  
}

void book_delteMenu(char *id,int fd, int sock)
{
    int re;
    int compare;
    int i = 0;
    BOOK book;
    char buffer[150];
    while(1)
    {
        fd_wrlock(i, fd);
        bzero(buffer, 150);
        strcpy(buffer, c_read(sock, "삭제할 도서의 식별 번호를 입력하세요: "));
        compare= atoi(buffer);
            lseek(fd, (long)(compare - START_ID)*sizeof(book), SEEK_SET);
            if(read(fd, (char *) &book, sizeof(book))>0 && (book.book_num!=0))
            {
                book.book_num = 0;
                lseek(fd, (long) -sizeof(book), SEEK_CUR);
                write(fd, (char*) &book, sizeof(book));

                break;
            }
        
        fd_unlock(i, fd);
        i++;
    }
}

void book_search(char * id, int fd, int sock)
{
    int re;
    int i = 1;
    int search;
    BOOK book;
    char buffer[250];
    bzero(buffer, 250);
    strcpy(buffer, c_read(sock, "검색할 도서의 식별번호를 입력하세요: "));
    search = atoi(buffer);
    while(1)
    {
        fd_rdlock(i, fd);
        re = read(fd, (char*) &book, sizeof(BOOK));
        if(re != sizeof(book)) 
        break;
        if((search == book.book_num) && book.book_num != 0)
        {
            c_print(sock, "ID | 도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
            c_print(sock,book.member_id);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d", book.book_num);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, book.book_name);c_print(sock, " "); 
            c_print(sock, book.book_name);c_print(sock, " ");
            c_print(sock, book.book_author);c_print(sock, " "); 
            c_print(sock, book.book_birth);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d",  book.book_price);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, book.book_review);c_print(sock, " ");
        }
        lseek(fd, i * sizeof(book), SEEK_SET);   
        fd_unlock(i, fd);
        i++;
    }
    close(fd);
}

void book_searchId(char*id,int fd, int sock)
{
    int re;
    int i = 1;
    char search[100];
    BOOK book;
    char buffer[250];
    bzero(search, 100);
    strcpy(search, c_read(sock, "검색할 도서의 이름을 입력하세요: "));
    while(1)
    {
        fd_rdlock(i, fd);
        re = read(fd, (char*) &book, sizeof(BOOK));
        if(re != sizeof(book)) 
        break;
        if(strstr(book.book_name, search) != NULL && book.book_num != 0)
        {
            c_print(sock, "도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
            bzero(buffer, 250);
            sprintf(buffer, "%d", book.book_num);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, book.book_name);c_print(sock, " "); 
            c_print(sock, book.book_name);c_print(sock, " ");
            c_print(sock, book.book_author);c_print(sock, " "); 
            c_print(sock, book.book_birth);c_print(sock, " ");
            bzero(buffer, 250);
            sprintf(buffer, "%d",  book.book_price);c_print(sock, buffer);c_print(sock, " ");
            c_print(sock, book.book_review);c_print(sock, " ");
        }
        lseek(fd, i * sizeof(book), SEEK_SET); 
        fd_unlock(i, fd);  
        i++;
    }
    close(fd);
}

void Update_Member(char* id, int fd, int sock)
{
   int re;
    int i = 1;
    char search[100];
    char buffer[150];
    Member member;
    c_print(sock, "개인정보 변경\n");
    while(1)
    {
        lseek(fd, (long)i * sizeof(member), SEEK_SET); 
        re = read(fd, (char*) &member, sizeof(member));
        if(!strcmp(id, member.member_id)){
                fd_rdlock(i, fd);
                bzero(member.member_password, 150);
                strcpy(member.member_password, c_read(sock, "password: "));
                bzero(member.member_name, 150);
                strcpy(member.member_name, c_read(sock, "name: "));
                bzero(member.member_phonenum, 150);
                strcpy(member.member_phonenum, c_read(sock, "phonenum: "));
                bzero(member.member_email, 150);
                strcpy(member.member_email, c_read(sock, "email: "));
                bzero(buffer, 150);
                strcpy(buffer, c_read(sock, "생년월일(YYMMDD): "));
                member.member_birth = atoi(buffer);
            lseek(fd, (long) -sizeof(member), SEEK_CUR); 
            write(fd, (char*) &member, sizeof(member));
            break;
        }
        fd_unlock(i, fd);  
        i++;
    }
    close(fd);
}
void book_print(int sock)
{
	c_print(sock, "1) List up All Book(Sort by 도서명)\n");
	c_print(sock, "2) List up All Book(Sort by 가격)\n");
	c_print(sock,"3) Add New Book\n");
	c_print(sock,"4) Update Book\n");
	c_print(sock,"5) Remove Book\n");
	c_print(sock,"6) Search Book Information by Title(minimum 2char)\n");
    c_print(sock,"7) Search Book information by Author\n");
    c_print(sock,"8) 개인정보 변경\n");
    c_print(sock,"0) Quit\n");
	c_print(sock,"Choose num > ");
}

void mainMenu(char *id, char* file, int sock)
{
	int start = -1;
    int read;
    int write;
    int mem_write;
	char buffer[256];
    while (start != 0)
	{
        read = Bookrdwr_file();
        write = Bookwrite_file();
        mem_write = Memberrdwr_file();
		bzero(buffer, 256);
        book_print(sock);
        strcpy(buffer, c_read(sock, "num: "));
        start = atoi(buffer);
		if (start == 1)
		{
			book_sortnameprint(id, read, sock);
		}
		else if (start == 2)
		{
            book_sortpriceprint(id, read, sock);
		}
		else if (start == 3)
		{
            book_addMenu(id, write, sock);   
		}
		else if (start == 4)
		{
            book_updateMenu(id, read, sock);
		}
		else if (start == 5)
		{
            book_delteMenu(id, read, sock);
		}
		else if (start == 6)
		{
           book_search(id, read, sock);
		}
        else if(start == 7)
        {
            book_searchId(id, read, sock);
        }
        else if(start == 8)
        {
            Update_Member(id, mem_write, sock);
        }
	}
}
/*여기까지 General 지금부터 Member*/
int Admin_member(char *id, char *file, int sock)
{
    Admin_mainMenu(id, file, sock);
}

int General(char *id, char * file,int sock)
{
    mainMenu(id, file, sock);
}
void Member_print(int sock)
{
	c_print(sock,"1) 회원 Login\n");
	c_print(sock, "2) 신규회원 가입\n");
    c_print(sock, "0) Quit\n");

}
void Login(int fd, int sock)
{
    char id[150];
    char password[150];
    int i = 0;
    int count = 0;
    Member member, temp;
    int compare = 0;
    int ret = 0;
    while(count!=3)
    {
        lseek(fd, 0, SEEK_SET);
        c_print(sock,"1. 회원 Login \n");
        c_print(sock, "id와 password를 입력하세요\n");
        bzero(id, 150);
        strcpy(id, c_read(sock, "id: "));
        bzero(password, 150);
        strcpy(password, c_read(sock, "password: "));
        for (int i;; i++)
        {
           
            ret = read(fd, (char *)&member, sizeof(member));
            if (ret != sizeof(member))
            {
                i = 0;
             
                break;
            }
            if (!strcmp(id, member.member_id) && !strcmp(password, member.member_password)&& !strcmp(member.member_admin, "N"))
            {
            
                compare = 1;
                break;
            }
            else if(!strcmp(id, member.member_id) && !strcmp(password, member.member_password)&& !strcmp(member.member_admin, "Y"))
            {
                compare = 2;
                break;
            }
            else
            {

                compare = 0;
            }
            lseek(fd, i * sizeof(member), SEEK_SET);
        }

        count++;
        if (compare == 1 || compare == 2)
            break;
        else
        {
            c_print(sock, "로그인 잘못했습니다.\n");
        }
    }
        if(count == 3) return;
        if (compare == 1)
        {
            c_print(sock, "General 로그인 성공!\n");
            General(id ,"book.dbx", sock);
        }
        else if (compare == 2)
        {
            c_print(sock, "Admin 로그인 성공!\n");
            Admin_member(id, "book.dbx", sock);
        }
    close(fd);
}

void Member_add(int fd, int sock)
{
    Member member, temp;
    char id[150], buffer[150];
    int a = 0;
    int i=0;
    c_print(sock, "<3. 신규회원가입>\n");
    bzero(member.member_id, 150);
    strcpy(member.member_id, c_read(sock, "id :"));
    int count3 = 1;
    while(1)
    {
        int ret = read(fd, (char*)&temp, sizeof(temp));
        if (ret != sizeof(temp)) 
        {
            break;
        }
        if(!strcmp(temp.member_id, member.member_id)){
            strcpy(id, temp.member_id);
            break;
        }
        lseek(fd, i * sizeof(temp), SEEK_SET);
        count3 = i;
        i++;
    }
    member.member_num = count3;
    if(!strcmp(id, member.member_id)){
        c_print(sock, "중복된 계정이 있습니다.\n");
        return;
    }
    if(member.member_num!=0)
    {
        if(strcmp(id, member.member_id)!= 0)
        {
            bzero(member.member_password, 150);
            strcpy(member.member_password, c_read(sock, "password: "));
            bzero(member.member_name, 150);
            strcpy(member.member_name, c_read(sock, "name: "));
            bzero(member.member_phonenum, 150);
            strcpy(member.member_phonenum, c_read(sock, "phonenum: "));
            bzero(member.member_email, 150);
            strcpy(member.member_email, c_read(sock, "email: "));
            bzero(buffer, 150);
            strcpy(buffer, c_read(sock, "생년월일(YYMMDD): "));
            member.member_birth = atoi(buffer);
            bzero(member.member_admin, 1);
            strcpy(member.member_admin, c_read(sock, "Admin 여부(Y/N): "));
            c_print(sock, "회원 가입 성공!\n");
            lseek(fd, (member.member_num - START_ID) * sizeof(member), SEEK_SET);
            write(fd, (char *)&member, sizeof(member));
        }
    }
    
    close(fd);
}
void c_print(int sock, char* msg)
{
    int n;
    n = write(sock, msg, strlen(msg));
    if(n < 0)
      error("ERROR writing to socket");
}
char *c_read(int sock, char* msg)
{
    static char buffer[256];
    int num;

    bzero(buffer, 256);
    c_print(sock, msg);
    num = read(sock, buffer, 256);
    if(num <0)
    error("NOT READING FROM SOCKET");
    return (buffer);
}
void dostuff(int); /* function prototype */
void error(char *msg)
{
    perror(msg);
    exit(1);
}

int main(int argc, char *argv[])
{
     int sockfd, newsockfd, portno, clilen, pid;
     struct sockaddr_in serv_addr, cli_addr;

     if (argc < 2) {
         fprintf(stderr,"ERROR, no port provided\n");
         exit(1);
     }
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0)
        error("ERROR opening socket");
     bzero((char *) &serv_addr, sizeof(serv_addr));
     portno = atoi(argv[1]);
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;
     serv_addr.sin_port = htons(portno);
     if (bind(sockfd, (struct sockaddr *) &serv_addr,
              sizeof(serv_addr)) < 0)
              error("ERROR on binding");
     listen(sockfd,5);
     clilen = sizeof(cli_addr);
     while (1) {
         newsockfd = accept(sockfd,(struct sockaddr *) &cli_addr, &clilen);
         if (newsockfd < 0)
             error("ERROR on accept");
         pid = fork();
         if (pid < 0)
             error("ERROR on fork");
         if (pid == 0)  {
             close(sockfd);
             dostuff(newsockfd);
             exit(0);
         }
         else close(newsockfd);
     } /* end of while */
     return 0; /* we never get here */
}

/******** DOSTUFF() *********************
 *  There is a separate instance of this function 
 *   for each connection.  It handles all communication
 *    once a connnection has been established.
 *     *****************************************/
void dostuff (int sock)
{
   int n;
   char buffer[256];    
    int input, read, f_write;
   for(;;)
   {
    read = Memberrdwr_file();
    f_write = Memberwrite_file();
      Member_print(sock); 
      bzero(buffer, 256);
      strcpy(buffer, c_read(sock, "input: "));
      input = atoi(buffer);
		if (input == 1)
		{
			Login(read, sock);
		}
		else if (input == 2)
		{
            Member_add(f_write, sock);
		}
        else if(input == 0)
        {
            break;
        }
   }

}

