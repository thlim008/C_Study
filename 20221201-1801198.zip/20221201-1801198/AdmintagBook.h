#define START_ID 0
typedef struct AdmintagBook
{
    int book_num;
    char book_name[150];
    char book_author[150];
    char book_birth[150];
    char book_review[150];
    int book_price;
}AdminBook;


