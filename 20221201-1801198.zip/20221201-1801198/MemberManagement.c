#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
//#include"tagBook.h"
#include<sys/types.h>
#include<sys/stat.h>
#include<dirent.h>
#include<time.h>
#include"MemberData.h"
#include"General.c"
#include"Admin.c"
int Memberwrite_file(char *file)
{
    int fd = open(file, O_RDWR | O_CREAT, 0644);
    return fd;
}
int Memberrdwr_file(char *file)
{
    int fd = open(file, O_RDWR, 0644);
    return fd;
}
int Memberfd_rdlock(int id, int fd)
{
    struct flock lock;
    Member member;
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = id*sizeof(member);
    lock.l_len = sizeof(member);

    return fcntl(fd, F_SETLKW, &lock);
}
int Memberfd_unlock(int id, int fd)
{
    struct flock lock;
    Member member;
    lock.l_type = F_UNLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = id*sizeof(member);
    lock.l_len = sizeof(member);

    return fcntl(fd, F_SETLK, &lock);
}
int Memberfd_wrlock(int id, int fd)
{
    struct flock lock;
    Member member;
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = id*sizeof(member);
    lock.l_len = sizeof(member);

    return fcntl(fd, F_SETLK, &lock);
}
void Member_print()
{
	printf("1) 회원 Login\n");
	printf("2) 신규회원 가입\n");
    printf("0) Quit\n");
	printf("Choose num > ");
}
void Login(int fd)
{
    char id[150];
    char password[150];
    int i = 0;
    int count = 0;
    Member member, temp;
    int compare = 0;
    int ret = 0;
    while(count!=3)
    {
        lseek(fd, 0, SEEK_SET);
        printf("1. 회원 Login \n");
        printf("id와 password를 입력하세요\n");
        printf("id: ");
        scanf("%s", id);
        printf("password: ");
        scanf("%s", password);
        for (int i;; i++)
        {
            ret = read(fd, (char *)&member, sizeof(member));
            if (ret != sizeof(member))
            {
                i = 0;
                break;
            }
            if (!strcmp(id, member.member_id) && !strcmp(password, member.member_password)&& member.member_admin == 'N')
            {
                compare = 1;
                break;
            }
            else if(!strcmp(id, member.member_id) && !strcmp(password, member.member_password)&& member.member_admin == 'Y')
            {
                compare = 2;
                break;
            }
            else
            {
                compare = 0;
            }
            lseek(fd, i * sizeof(member), SEEK_SET);
        }
        count++;
        if (compare == 1 || compare == 2)
            break;
        else
        {
            printf("로그인 잘못했습니다.\n");
        }
    }
        if(count == 3) return;
        if (compare == 1)
        {
            printf("General 로그인 성공!\n");
            General(id ,"book.db");
            for(int i = 0; i< 149; i++)
            {
                id[i] = 0;
            }
        }
        else if (compare == 2)
        {
            printf("Admin 로그인 성공!\n");
            Admin_member("book.db");
            for(int i = 0; i< 149; i++)
            {
                id[i] = 0;
            }
        }
    close(fd);
}
/*void admin_login(int fd)
{
    
    int i = 0;
    int count = 0;
    char id[150];
    char password[150];
    Member member, temp;
    int compare = 0;
    char compare_admin[150];
    while(count !=3)
    {
        lseek(fd, 0, SEEK_SET);
        printf("2. Admin Login \n");
        printf("id와 password를 입력하세요\n");
        printf("id: ");
        scanf("%s", id);
        printf("password: ");
        scanf("%s", password);
        while(1)
        {
            int ret = read(fd, (char *)&member, sizeof(member));
            if (ret != sizeof(member))
            {
                break;
            }
            if (!strcmp(id, member.member_id) && !strcmp(password, member.member_password) && member.member_admin == 'Y')
            {
                compare = 1;
                break;
            }
            else{
                compare =0;
            }
            lseek(fd, i * sizeof(temp), SEEK_SET);
            i++;
        }
        count++;
        if(compare == 1)break;
        else printf("다시 입력하세요\n");
    }
        if(count == 3) return;
        if (compare == 1)
        {
            printf("로그인 성공!\n");
            Admin_member("book.db");
        }
    close(fd);
}
*/
void Member_add(int fd)
{
    Member member, temp;
    char id[150];
    int a = 0;
    int i=0;
    printf("<3. 신규회원가입>\n");
    printf("id :");
    int count = 1;
    scanf("%s",member.member_id);
    while(1)
    {
        int ret = read(fd, (char*)&temp, sizeof(temp));
        if (ret != sizeof(temp)) 
        {
            break;
        }
        if(!strcmp(temp.member_id, member.member_id)){
            strcpy(id, temp.member_id);
            break;
        }
        lseek(fd, i * sizeof(temp), SEEK_SET);
        count = i;
        i++;
    }
    member.member_num = count;
    if(!strcmp(id, member.member_id)){
        printf("중복된 계정이 있습니다.");
        return;
    }
    if(member.member_num!=0)
    {
        if(strcmp(id, member.member_id)!= 0){
        printf("password | 회원이름 | 휴대폰번호 | 이메일 | 생년월일(YYMMDD) | admin여부(Y/N)\n");
        scanf("%s %s %s %s %d %c",member.member_password,member.member_name,member.member_phonenum,member.member_email,&member.member_birth,&member.member_admin);
        printf("회원 가입 성공!\n");
        lseek(fd, (member.member_num - START_ID) * sizeof(member), SEEK_SET);
        write(fd, (char *)&member, sizeof(member));
    }
    }
    
    close(fd);
}
void Member_Menu(char* file)
{
    int start = -1;
    int read;
    int write;
	while (start != 0)
	{
        read = Memberrdwr_file(file);
        write = Memberwrite_file(file);
        int pid = fork();
        if(pid ==0)
        {
            Member_print();
            exit(0);
        }
		scanf("%d", &start);
		if (start == 1)
		{
			Login(read);
		}
		else if (start == 2)
		{
            Member_add(write);
		}
	}
}
int main(int argc, char*argv[])
{
    Member_Menu(argv[1]);
}