#define START_ID 0
typedef struct AdminMember
{
    int member_num;
    char member_id[150];
    char member_password[150];
    char member_name[150];
    char member_phonenum[150];
    char member_email[150];
    int member_birth;
    char member_admin;
}Admin;


