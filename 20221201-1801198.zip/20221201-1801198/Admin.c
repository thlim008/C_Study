#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include"AdminMember.h"
#include<sys/types.h>
#include<sys/stat.h>
#include<dirent.h>
#include<time.h>
#include"AdmintagBook.h"
int Adminwrite_file(char *file)
{
    int fd = open(file, O_RDWR | O_CREAT, 0644);
    return fd;
}
int Adminrdwr_file(char *file)
{
    int fd = open(file, O_RDWR, 0644);
    return fd;
}
int Admin_member_rdwr_file()
{
    int fd = open("Member.db", O_RDWR);
    return fd;
}
int Adminfd_rdlock(int id, int fd)
{
    struct flock lock;
    AdminBook book;
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = id*sizeof(book);
    lock.l_len = sizeof(book);

    return fcntl(fd, F_SETLKW, &lock);
}
int Adminfd_unlock(int id, int fd)
{
    struct flock lock;
    AdminBook book;
    lock.l_type = F_UNLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = id*sizeof(book);
    lock.l_len = sizeof(book);

    return fcntl(fd, F_SETLK, &lock);
}
int Adminfd_wrlock(int id, int fd)
{
    struct flock lock;
    AdminBook book;
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = id*sizeof(book);
    lock.l_len = sizeof(book);

    return fcntl(fd, F_SETLK, &lock);
}
void Adminbook_sortnumprint(int fd)
{
    int re;
    AdminBook book;
    int i = 0;
    printf("도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
    while(1)
    {
        Adminfd_rdlock(i, fd);
        re = read(fd, &book, sizeof(book));
        if(re != sizeof(book)) break;
        if(book.book_num!=0)
        {
            printf("%d %s %s %s %d %s\n",book.book_num , book.book_name, book.book_author, book.book_birth, book.book_price, book.book_review);
        }
        lseek(fd, i*sizeof(book), SEEK_SET); 
        Adminfd_unlock(i,fd); 
        i++; 
    }
    close(fd);
}

void Adminbook_sortnameprint(int fd)
{
    AdminBook book_data;
    AdminBook temp;
    AdminBook name_sort[150] = {0, };
    int i = 0;
    int n = sizeof(name_sort)/sizeof(book_data);
    while(1)
    {
        Adminfd_rdlock(i, fd);   
        int ret = read(fd, (char*)&book_data, sizeof(book_data));
        if(ret != sizeof(book_data)) break;
        name_sort[i] = book_data;

        i++;
    }
    for(int i = 0; i < n - 1; i++)
    {
        for(int j = i + 1; j < n; j++)
        {
            if(strcmp(name_sort[i].book_name, name_sort[j].book_name) > 0)
            {
                temp = name_sort[i];
                name_sort[i] = name_sort[j];
                name_sort[j] = temp;
            }
        }
    }
    printf("도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
    for(int i = 0; i < n; i++) 
    {
        if(name_sort[i].book_num != 0)
        {
            printf("%d %s %s %s %d %s\n",name_sort[i].book_num , name_sort[i].book_name, name_sort[i].book_author, name_sort[i].book_birth, name_sort[i].book_price, name_sort[i].book_review);
        }
        Adminfd_unlock(i, fd);              
    }
    close(fd);
}
void Adminbook_addMenu(int fd)
{
    char answer = 's';
    AdminBook book;
    int i =0;
    do
    {
            Adminfd_wrlock(i, fd);
	        printf("도서 정보를 입력하세요\n");
            printf("도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
            scanf("%d %s %s %s %d %[^\n]s ",&book.book_num , book.book_name, book.book_author, book.book_birth, &book.book_price, book.book_review);
            lseek(fd, book.book_num * sizeof(book), SEEK_SET);  
            write(fd, &book, sizeof(AdminBook));
            printf("계속 입력 하겠습니까?(y/n)");
            scanf(" %c", &answer);
            Adminfd_unlock(i, fd);
            i++;
    }while(answer == 'y');
    close(fd);
}
void Adminbook_updateMenu(int fd)
{
    int re;
    int compare;
    int i =0;
    AdminBook book;
    while(1)
    {
        printf("수정할 도서의 식별 번호를 입력하세요");
        Adminfd_wrlock(i, fd);
        if(scanf("%d", &compare) == 1)
        {
            lseek(fd, (long)(compare - START_ID)*sizeof(book), SEEK_SET);
            if(read(fd, (char *)&book, sizeof(book))>0 && (book.book_num!=0))
            {
                printf("도서 정보를 입력하세요\n");
                printf("도서이름 | 저자 | 출판년월일 | 가격 | 리뷰\n");
                scanf("%s %s %s %d %[^\n]s",book.book_name, book.book_author, book.book_birth, &book.book_price, book.book_review);
                lseek(fd, (long) -sizeof(book), SEEK_CUR);
                write(fd, (char*) &book, sizeof(book));
                break;
            }
            
        }
        Adminfd_unlock(i, fd);
        i++;
    }
    close(fd);  
}
void Adminbook_delteMenu(int fd)
{
    int re;
    int compare;
    int i = 0;
    AdminBook book;
    while(1)
    {
        Adminfd_wrlock(i, fd);
        printf("삭제할 도서의 식별 번호를 입력하세요");
        if(scanf("%d", &compare) == 1)
        {
            lseek(fd, (long)(compare - START_ID)*sizeof(book), SEEK_SET);
            if(read(fd, (char *) &book, sizeof(book))>0 && (book.book_num!=0))
            {
                book.book_num = 0;
                lseek(fd, (long) -sizeof(book), SEEK_CUR);
                write(fd, (char*) &book, sizeof(book));

                break;
            }
        }
        Adminfd_unlock(i, fd);
        i++;
    }
    close(fd);
}
void Adminbook_search(int fd)
{
    int re;
    int i = 1;
    char search[100];
    AdminBook book;
    printf("검색할 도서의 이름을 적으시오");
    scanf("%s", search);
    while(1)
    {
        Adminfd_rdlock(i, fd);
        re = read(fd, (char*) &book, sizeof(AdminBook));
        if(re != sizeof(book)) 
        break;
        if(strstr(book.book_name, search) != NULL && book.book_num != 0)
        {
            printf("도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
            printf("%d %s %s %s %d %s\n",book.book_num , book.book_name, book.book_author, book.book_birth, book.book_price, book.book_review);
        }
        lseek(fd, i * sizeof(book), SEEK_SET); 
        Adminfd_unlock(i, fd);  
        i++;
    }
    close(fd);
}
void Adminbook_searchId(int fd)
{
    int re;
    int i = 1;
    int search;
    AdminBook book;
    printf("검색할 도서의 식별번호을 적으시오");
    scanf("%d", &search);
    while(1)
    {
        Adminfd_rdlock(i, fd);
        re = read(fd, (char*) &book, sizeof(AdminBook));
        if(re != sizeof(book)) 
        break;
        if((search == book.book_num) && book.book_num != 0)
        {
            printf("도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
            printf("%d %s %s %s %d %s\n",book.book_num , book.book_name, book.book_author, book.book_birth, book.book_price, book.book_review);
        }
        lseek(fd, i * sizeof(book), SEEK_SET);   
        Adminfd_unlock(i, fd);
        i++;
    }
    close(fd);
}
void Admin_Memberprint(int fd)
{
    int re;
    Admin member;
    int i = 0;
    while(1)
    {
        Adminfd_rdlock(i, fd);
        re = read(fd, &member, sizeof(member));
        if(re != sizeof(member)) break;
        if(member.member_num!=0)
        {
            printf("%d %s %s %s %s %s %d %c\n",member.member_num,member.member_id,member.member_password,member.member_name,member.member_phonenum,member.member_email,member.member_birth,member.member_admin);
        }
        lseek(fd, i*sizeof(member), SEEK_SET); 
        Adminfd_unlock(i,fd); 
        i++; 
    }
    close(fd);
}
void Admin_MemberRemove(int fd)
{
    int re;
    int compare;
    int i = 0;
    char reset ='0';
    Admin member;
    while(1)
    {
        Adminfd_wrlock(i, fd);
        printf("삭제할 회원의 식별 번호를 입력하세요");
        if(scanf("%d", &compare) == 1)
        {
            lseek(fd, (long)(compare - START_ID)*sizeof(member), SEEK_SET);
            if(read(fd, (char *) &member, sizeof(member))>0 && (member.member_num!=0))
            {

                strcpy(member.member_id, "0");
                member.member_admin = reset;
                member.member_birth = 0;
                strcpy(member.member_password, "0");
                strcpy(member.member_phonenum, "0");
                member.member_num = 0;
                strcpy(member.member_name, "0");
                strcpy(member.member_email, "0");
                lseek(fd, (long) -sizeof(member), SEEK_CUR);
                write(fd, (char*) &member, sizeof(member));

                break;
            }
        }
        Adminfd_unlock(i, fd);
        i++;
    }
    close(fd);
}
void Admin_Memberupdate(int fd)
{
    int re;
    int compare;
    int i =0;
    Admin member;
    while(1)
    {
        printf("회원 식별 번호를 입력하세요");
        Adminfd_wrlock(i, fd);
        if(scanf("%d", &compare) == 1)
        {
            lseek(fd, (long)(compare - START_ID)*sizeof(member), SEEK_SET);
            if(read(fd, (char *)&member, sizeof(member))>0 && (member.member_num!=0))
            {
                printf("회원 식별 번호를 입력하세요");
                printf("id | password | 회원이름 | 휴대폰번호 | 이메일 | 생년월일(YYMMDD)\n");
                scanf("%s %s %s %s %s %d", member.member_id ,member.member_password,member.member_name,member.member_phonenum,member.member_email,&member.member_birth);
                lseek(fd, (long) -sizeof(member), SEEK_CUR);
                write(fd, (char*) &member, sizeof(member));
                break;
            }
            
        }
        Adminfd_unlock(i, fd);
        i++;
    }
    close(fd);  
}
void Admin_book_print()
{
	printf("1) List up All Book(Sort by 식별자)\n");
	printf("2) List up All Book(Sort by 도서명)\n");
	printf("3) Add New Book\n");
	printf("4) Update Book\n");
	printf("5) Remove Book\n");
	printf("6) Search Book Information by Title(minimum 2char)\n");
    printf("7) 회원리스트 보기\n");
    printf("8) 회원정보 삭제\n");
    printf("9) 회원 정보 갱신\n");
    printf("0) Quit\n");
	printf("Choose num > ");
}

void Admin_mainMenu(char* file)
{
	int start = -1;
    int read;
    int write;
    int member;
	while (start != 0)
	{
        read = Adminrdwr_file(file);
        write = Adminwrite_file(file);
        member = Admin_member_rdwr_file();
		Admin_book_print();
		scanf("%d", &start);
		if (start == 1)
		{
			Adminbook_sortnumprint(read);
		}
		else if (start == 2)
		{
            Adminbook_sortnameprint(read);
		}
		else if (start == 3)
		{
            Adminbook_addMenu(write);   
		}
		else if (start == 4)
		{
            Adminbook_updateMenu(read);
		}
		else if (start == 5)
		{
            Adminbook_delteMenu(read);
		}
		else if (start == 6)
		{
           Adminbook_search(read);
		}
        else if(start == 7)
        {
            Admin_Memberprint(member);
        }
        else if(start == 8)
        {
            Admin_MemberRemove(member);
        }
        else if(start == 9)
        {
            Admin_Memberupdate(member);
        }
	}
}
int Admin_member(char *file)
{
    Admin_mainMenu(file);
}