#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include"tagBook.h"
#include<sys/types.h>
#include<sys/stat.h>
#include<dirent.h>
#include<time.h>
#include"GeneralMember.h"
int write_file(char *file)
{
    int fd = open(file, O_RDWR | O_CREAT, 0644);
    return fd;
}
int rdwr_file(char *file)
{
    int fd = open(file, O_RDWR, 0644);
    return fd;
}
int fd_rdlock(int id, int fd)
{
    struct flock lock;
    Book book;
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = id*sizeof(book);
    lock.l_len = sizeof(book);

    return fcntl(fd, F_SETLKW, &lock);
}
int fd_unlock(int id, int fd)
{
    struct flock lock;
    Book book;
    lock.l_type = F_UNLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = id*sizeof(book);
    lock.l_len = sizeof(book);

    return fcntl(fd, F_SETLK, &lock);
}
int fd_wrlock(int id, int fd)
{
    struct flock lock;
    Book book;
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = id*sizeof(book);
    lock.l_len = sizeof(book);

    return fcntl(fd, F_SETLK, &lock);
}


void book_sortnameprint(char *id, int fd)
{
    Book book_data;
    Book temp;
    Book name_sort[150] = {0, };
    int i = 0;
    int n = sizeof(name_sort)/sizeof(book_data);
    while(1)
    {
        fd_rdlock(i, fd);   
        int ret = read(fd, (char*)&book_data, sizeof(book_data));
        if(ret != sizeof(book_data)) break;
        name_sort[i] = book_data;

        i++;
    }
    for(int i = 0; i < n - 1; i++)
    {
        for(int j = i + 1; j < n; j++)
        {
            if(strcmp(name_sort[i].book_name, name_sort[j].book_name) > 0 && !strcmp(id, name_sort[i].member_id))
            {
                temp = name_sort[i];
                name_sort[i] = name_sort[j];
                name_sort[j] = temp;
            }
        }
    }
    printf("도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
    for(int i = 0; i < n; i++) 
    {
        if(name_sort[i].book_num != 0&& book_data.member_id ==id)
        {
            printf("%d %s %s %s %d %s\n",name_sort[i].book_num , name_sort[i].book_name, name_sort[i].book_author, name_sort[i].book_birth, name_sort[i].book_price, name_sort[i].book_review);
        }
        fd_unlock(i, fd);              
    }
    close(fd);
}
void book_sortpriceprint(int fd)
{
    Book book, temp;
    Book price_sort[150] = {0,};
    int i = 0;
    int n = sizeof(price_sort)/sizeof(book);
    while(1)
    {
        fd_rdlock(i, fd);
        int ret = read(fd, (char*) &book, sizeof(book));
        if(ret != sizeof(book))break;
        price_sort[i] = book;
        i++;
    }
    for(int i = 0; i < n -1; i++)
    {
        for(int j = i +1; j<n; j++)
        {
            if(price_sort[i].book_price > price_sort[j].book_price)
            {
                    temp = price_sort[i];
                    price_sort[i] = price_sort[j];
                    price_sort[j] =temp;
            }
        }
    }
    int k = 0;
    printf("도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
    while(k != n)
    {
        if(price_sort[k].book_num!=0)
        {
            printf("%d %s %s %s %d %s\n",price_sort[k].book_num , price_sort[k].book_name, price_sort[k].book_author, price_sort[k].book_birth, price_sort[k].book_price, price_sort[k].book_review);
        }
        fd_unlock(k,fd); 
        k++; 
    }
    close(fd);
}
void book_addMenu(char * id, int fd)
{
    char answer = 's';
    Book book;
    int i =0;
    do
    {
            fd_wrlock(i, fd);
	        printf("도서 정보를 입력하세요\n");
            printf("도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
            scanf("%d %s %s %s %d %[^\n]s ",&book.book_num , book.book_name, book.book_author, book.book_birth, &book.book_price, book.book_review);
            strcpy(book.member_id, id);
            if(book.member_id != 0)
            {
                lseek(fd, book.book_num * sizeof(book), SEEK_SET);  
                write(fd, &book, sizeof(Book));
                printf("계속 입력 하겠습니까?(y/n)");
                scanf(" %c", &answer);
                break;
            }
            //else return;
            fd_unlock(i, fd);
            i++;
    }while(answer == 'y');
    close(fd);
}
void book_updateMenu(int fd)
{
    int re;
    int compare;
    int i =0;
    Book book;
    while(1)
    {
        printf("수정할 도서의 식별 번호를 입력하세요");
        fd_wrlock(i, fd);
        if(scanf("%d", &compare) == 1)
        {
            lseek(fd, (long)(compare - START_ID)*sizeof(book), SEEK_SET);
            if(read(fd, (char *)&book, sizeof(book))>0 && (book.book_num!=0))
            {
                printf("도서 정보를 입력하세요\n");
                printf("도서이름 | 저자 | 출판년월일 | 가격 | 리뷰\n");
                scanf("%s %s %s %d %[^\n]s",book.book_name, book.book_author, book.book_birth, &book.book_price, book.book_review);
                lseek(fd, (long) -sizeof(book), SEEK_CUR);
                write(fd, (char*) &book, sizeof(book));
                break;
            }
            
        }
        fd_unlock(i, fd);
        i++;
    }
    close(fd);  
}
void book_delteMenu(int fd)
{
    int re;
    int compare;
    int i = 0;
    Book book;
    while(1)
    {
        fd_wrlock(i, fd);
        printf("삭제할 도서의 식별 번호를 입력하세요");
        if(scanf("%d", &compare) == 1)
        {
            lseek(fd, (long)(compare - START_ID)*sizeof(book), SEEK_SET);
            if(read(fd, (char *) &book, sizeof(book))>0 && (book.book_num!=0))
            {
                book.book_num = 0;
                lseek(fd, (long) -sizeof(book), SEEK_CUR);
                write(fd, (char*) &book, sizeof(book));

                break;
            }
        }
        fd_unlock(i, fd);
        i++;
    }
    close(fd);
}
void book_search(char * id, int fd)
{
    int re;
    int i = 1;
    char search[100];
    Book book;
    printf("검색할 도서의 이름을 적으시오");
    scanf("%s", search);
    while(1)
    {
        fd_rdlock(i, fd);
        re = read(fd, (char*) &book, sizeof(Book));
        if(re != sizeof(book)) 
        break;
        if(strstr(book.book_name, search) != NULL && book.book_num != 0 && book.member_id ==id)
        {
            printf("도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
            printf("%d %s %s %s %d %s\n",book.book_num , book.book_name, book.book_author, book.book_birth, book.book_price, book.book_review);
        }
        lseek(fd, i * sizeof(book), SEEK_SET); 
        fd_unlock(i, fd);  
        i++;
    }
    close(fd);
}
void book_searchId(char*id,int fd)
{
    int re;
    int i = 1;
    char search[100];
    Book book;
    printf("검색할 도서의 저자을 적으시오");
    scanf("%s", search);
    while(1)
    {
        fd_rdlock(i, fd);
        re = read(fd, (char*) &book, sizeof(Book));
        if(re != sizeof(book)) 
        break;
        if(strstr(book.book_author, search) != NULL && book.book_author != 0 && book.member_id ==id)
        {
            printf("도서 식별번호 | 도서이름 | 저자 | 출판년월일 | 가격 | 리뷰 \n");
            printf("%d %s %s %s %d %s\n",book.book_num , book.book_name, book.book_author, book.book_birth, book.book_price, book.book_review);
        }
        lseek(fd, i * sizeof(book), SEEK_SET); 
        fd_unlock(i, fd);  
        i++;
    }
    close(fd);
}
void book_print()
{
	printf("1) List up All Book(Sort by 도서명)\n");
	printf("2) List up All Book(Sort by 가격)\n");
	printf("3) Add New Book\n");
	printf("4) Update Book\n");
	printf("5) Remove Book\n");
	printf("6) Search Book Information by Title(minimum 2char)\n");
    printf("7) Search Book information by Author\n");
    printf("0) Quit\n");
	printf("Choose num > ");
}

void mainMenu(char *id, char* file)
{
	int start = -1;
    int read;
    int write;
	while (start != 0)
	{
        read = rdwr_file(file);
        write = write_file(file);
		book_print();
		scanf("%d", &start);
		if (start == 1)
		{
			book_sortnameprint(id, read);
		}
		else if (start == 2)
		{
            book_sortpriceprint(read);
		}
		else if (start == 3)
		{
            book_addMenu(id, write);   
		}
		else if (start == 4)
		{
            book_updateMenu(read);
		}
		else if (start == 5)
		{
            book_delteMenu(read);
		}
		else if (start == 6)
		{
           book_search(id, read);
		}
        else if(start == 7)
        {
            book_searchId(id, read);
        }
	}
}
int General(char *id, char * file)
{
    mainMenu(id, file);
}